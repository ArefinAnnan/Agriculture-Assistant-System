<?php 

include_once 'CRUD.php';

$crud = new Crud();

if(isset($_POST['send']))
{
    $subject = $_POST['subject'];
    $messege = $_POST['messege'];
    $receiver = $_POST['sender'];
    $client = $_POST['client'];
    $sender ='support';
    

    $query = "select COUNT(id) from support where sender = '$sender' AND receiver = '$receiver'";

    $check = $crud->getData($query);

    foreach($check as $chk)
	{
		$checkmsg = $chk["COUNT(id)"];
	}
    
    if($checkmsg == 1)
    {
        echo "<script>alert('You Already answer to this messege.')</script>";
    }
    else{
        $result =  $crud->execute("INSERT into support(sender, receiver, subject , messege, client) values ('$sender', '$receiver', '$subject', '$messege', '$client')");
    
    if($result)
    {
        echo "<script>alert('Success')</script>";
        header("location:case.php");
    }
    else
    {
        echo "Problem!";
    }
    }
}
?>