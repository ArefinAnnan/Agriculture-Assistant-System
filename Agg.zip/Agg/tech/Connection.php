
<?php
$conn = mysqli_connect("localhost","root","","agg");

if(!$conn)
{
	echo "Database connection faild...";
}
?>