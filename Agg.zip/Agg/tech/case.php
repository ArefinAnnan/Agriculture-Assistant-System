<?php

include_once 'CRUD.php';

$crud = new Crud();


$query = "Select * from support where receiver = 'support' AND sender!='support'";

$result = $crud->getData($query);

?>
<?php

include_once('header1.php');

?> 
<div id="account"> 

      <br> 
      <br> 
      <br> 
        
          <!DOCTYPE html> 
<!DOCTYPE html> 
<html>      
<head> 
  <title>Case page</title>  
</head> 
<body> 
    <h1 align="center"> Problem Solution</h1>    
</body> 
</html> 
<br> 
<br> 

<?php foreach( $result as $res){?>
  <div class="form-group"> 
    <label class="control-label col-sm-2" for="">Case : 
      <span name="Case" class="form-control" id="Case" style="color: red;, font-weight:bold;"><?php echo $res['subject']?></span> <span><a href="chat.php?id=<?php echo $res['sender'] ?>" class="btn btn-primary">Reply</a></span>
    </label>
  </div>
  <?php } ?>

    <br> 
    <br> 
      </div> 
    </div> 
    
    </div> 
    </div>     
