
<?php
include_once('link.php');

?> 
 
<nav class="navbar navbar-default"> 
	<div class="container-fluid"> 
		<div class="navbar-header"> 
			<a href="#" class="navbar-brand">Registration Login</a> 
		</div> 
		<ul class="nav navbar-nav"> 
			<li><a href="registration.php">Registration</a></li> 
			<li><a href="login.php">Login</a></li> 
		</ul> 
	</div> 
</nav>