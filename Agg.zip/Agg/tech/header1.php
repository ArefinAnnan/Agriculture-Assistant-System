
<?php

?> 

<nav class="navbar navbar-default"> 
	<div class="container-fluid"> 
		<div class="navbar-header"> 
			<a href="#" class="navbar-brand">Home Page</a> 
		</div> 
		<div class="dropdown navbar-right" id="right"> 

  <span class="caret"></span></button> 
  <ul class="dropdown-menu"> 
  	<li><a href="welcome.php">Home</a></li> 
  	<li><a href="account.php">Account</a></li> 
    <li><a href="logout.php">Logout</a></li> 
    <li><a href="case.php">Case</a></li> 

  </ul> 
</div> 
	</div> 
</nav>