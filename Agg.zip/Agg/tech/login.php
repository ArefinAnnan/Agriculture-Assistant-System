
<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
</head>
<body  align="center" bgcolor="DarkCyan">
	<fieldset>
				<legend><h1>Login</h1></legend>
	<form action="Login.php" method="POST">
		<label for="username">Username: </label>
		<input type="text" name="username" id="username" value="">

		<br><br>

		<label for="password">Password: </label>
		<input type="password" name="password" id="password" value="">

		<br><br>

		<input type="checkbox" name="rememberme" id="rememberme" value="1">
		<label for="rememberme">Remember Me</label>

		<input type="submit" name="login" value="Login">

	</fieldset>	
	</form>

	<br>


	Not yet a Member? <a href="Registration.php">Sign Up</a>

	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    
    

</body>
</html>

<?php
include_once "CRUD.php";
$crud = new Crud();

if(isset($_POST['login']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];

	$query = "select * from tecnical_team where username='$username' AND password='$password'";
	
	$result = $crud->getData($query);
	
	foreach($result as $res)
	{
		$username= $res['username'];	
		
	}
	// var_dump($result);
	// die();

	if($username)
	{
		session_start();
		$_SESSION['username']=$username;
		header("location:welcome.php");
	}
	else
	{
		echo "<script>alert('Username or Password is Wrong')</>";
		//header("location:../Views/Login.php");
	}
}
?>
