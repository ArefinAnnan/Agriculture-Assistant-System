<?php

include_once 'CRUD.php';

$crud = new Crud();

$id = $_GET['id'];

$query = "Select * from support where sender = '$id' OR receiver = '$id'";


$result = $crud->getData($query);

// foreach($result as $res)
// {
//     var_dump($res['subject']);
//     die();
// }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
</head>
<body>
    <?php foreach($result as $res) {?>
    <span><?php echo $res['sender']?>: </span><span><?php echo $res['messege']; ?></span><br>
    <?php } ?>

<form action="chat_action.php" method="POST">
<?php foreach($result as $res) { ?>
    <input type="hidden" name='client' value=" <?php echo $res['client']; ?>">
    <input type="hidden" name='subject' value=" <?php echo $res['subject']; ?>">
    <input type="hidden" name='sender' value="<?php echo $res['sender']; ?>">
<?php  } ?>
    <input type="text" name="messege" placeholder="Enter Messege">
    <input type="submit" name="send" value='Send'>
</form>
</body>
</html>