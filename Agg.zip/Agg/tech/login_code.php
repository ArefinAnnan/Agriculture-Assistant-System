<?php
include_once "CRUD.php";
$crud = new Crud();

if(isset($_POST['login']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];

	$query = "select * from tecnical_team where username='$username' AND password='$password'";
	
	$result = $crud->getData($query);
	
	foreach($result as $res)
	{
		$username= $res['username'];	
		
	}

	if($result)
	{
		session_start();
		$_SESSION['username']=$username;
		header("location:case.php");
	}
	else
	{
		echo "<script>alert('Username or Password is Wrong')</script>";
		//header("location:../Views/Login.php");
	}
}
?>