
<?php

include_once('header1.php');

?> 
<div id="account"> 

        </div> 
        
    </div> 

        <div class="well"> 
          <ul class="dropdown-menu"> 
     
               <li><a href="Back.php">Back</a></li> 
             </ul> 
        </div> 
      <div class="tab-content"> 
        <div class="tab-pane fade in active" id="tab1"> 
          <table class="table" align="center"> 
          	<tr> 
          		<td>First Name:</td> 
          	
          	</tr> 
          	<tr> 
          		<td>Last Name:</td> 
          		
          	</tr> 
          	<tr> 
          		<td>Gender:</td> 
          		 
          	</tr> 
          	<tr>  
          		<td>Email:</td> 
          		
          	</tr> 
          </table> 
        
      </div> 
    </div> 
    
    </div> 
    </div>     
