
<?php
include_once('link.php');
include_once('header1.php');
require_once('connection.php');

?> 
<!DOCTYPE html> 
<!DOCTYPE html> 
<html>      
<head> 
	<title>Welcome page</title>  
</head> 
<body> 
        <h1 align="center"> Welcome Technical Support</h1> 
        <img src="Support.jpg" alt="" width="1500" height="450"> 

        <h1>List of sold Crops</h1>
        
        <h1>List of sold Pesticides</h1>
</body> 
</html> 
