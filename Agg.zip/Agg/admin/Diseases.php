<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once 'Crud.php';

$crud = new Crud();

$query = "Select * from disease order by id";

$result = $crud->getData($query);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Crops</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body bgcolor="DarkCyan">
	
	<br><br><br><br><br><br><br><br><br><br>
	<h1 align="center">Disease List with Details</h1>
	<br><br>
<form action="Diseases.php" method="POST" enctype="multipart/form-data"/>
	<center>
		<input type="text" name="d_name" placeholder="disease Name"/><br>
		<input type="text" name="d_details" placeholder="disease details"/><br>
		<input type="file" name="image" id="image" /> <br>
		<input type="submit" name="submit" value="Submit"><br>
	</center>
<form/>
<br>
<br>
<center>

	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col"> disease Name </td>
				<th scope="col"> disease Details </td>
				<th scope="col"> disease Photo</td>
			</tr>
	    </thead>
	    <tbody>
	<?php
		foreach($result as $key=>$res)
		{
			echo "<tr>";
			echo "<td>".$res['disease_name']."</td>";
			echo "<td>".$res['disease_details']."</td>";
			echo "<td><img src='data:image/jpeg;base64,".base64_encode($res['disease_photo'] )."' height='50' width='50' class='img-thumnail'/></td>";
			echo "</tr>";
		}
		?>
		</tbody>
	</table>
</center>

<div class="dis">
<h1> False Smut In Rice </h1>
	<img src="False Smut In Rice.jpg"  height="200" width="280"/>
    <p>Rice false smut disease, which is caused by the fungus Ustilaginoidea virens, is currently one of the most devastating rice fungal diseases in the world. Rice false smut disease not only causes severe yield loss and grain quality reduction, but also threatens food safety due to its production of mycotoxins.</p>
	</div>
	<br>
	<div class="dis1">
	<h1> Wirrega Blotch Lesions Expand To Whole Leaf</h1>
	<img src="Wirrega Blotch Lesions Expand To Whole Leaf.jpg" height="200" width="280"/>
    <p>Epidemiology. The leaf blotch disease is caused by Taphrina maculans, an ascomycetous fungus. The fungus is reported to be active during moist cloudy weather which is very common during the SW monsoon in India, especially during the months of August and September.</p>
    </div>
	<br>
	<div class="dis2">
		<h1>Youtube Link<h1>
	<p> <a href="https://www.youtube.com/watch?v=I8ni7l2bB1g">Crops and their diseases</a><p>
</body>
</html>
<?php 
	if(isset($_POST['submit']))
	{
		$d_name = $_POST['d_name'];
		$d_details = $_POST['d_details'];
		$d_img = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

		$result = $crud->execute("INSERT into disease(disease_name, disease_details, disease_photo) values ('$d_name','$d_details', '$d_img')");

		if($result)
		{
			echo "alert('sucess')";
			header("Location:Diseases.php");
		}
		else{
			echo "Insertion Problem!";
		}
	}
?>

<script>  
	$(document).ready(function(){  
		$('#submit').click(function(){  
			var image_name = $('#image').val();  
			if(image_name == '')  
			{  
					alert("Please Select Image");  
					return false;  
			}  
			else  
			{  
					var extension = $('#image').val().split('.').pop().toLowerCase();  
					if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
					{  
						alert('Invalid Image File');  
						$('#image').val('');  
						return false;  
					}  
			}  
		});  
	});  
</script>



