<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once 'Crud.php';

$crud = new Crud();

$query = "Select * from tecnical_team order by id";

$result = $crud->getData($query);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Tecnical Team List</title>
</head>
<body bgcolor="DarkCyan">
	
<br>
	<h1 align="center">Tecnical Team List</h1>
	<br><br><br>
<form action="TecnicalTeamlist.php" method="POST">
	<center>
		<input type="text" name="name" placeholder="Name"/><br>
		<input type="text" name="username" placeholder="Username"/><br>
		<input type="text" name="password" id="Password" placeholder="Password"/> <br>
		<input type="submit" name="submit" value="Submit"><br>
	</center>
<form/>
<br>
<br>
<center>

	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col"> Name </td>
				<th scope="col"> Username </td>
				<th scope="col"> Password Photo</td>
			</tr>
	    </thead>
	    <tbody>
	<?php
		foreach($result as $key=>$res)
		{
			echo "<tr>";
			echo "<td>".$res['name']."</td>";
			echo "<td>".$res['username']."</td>";
			echo "<td>".$res['password']."</td>";
			echo "</tr>";
		}
		?>
		</tbody>
	</table>
</center>

</body>
</html>
<?php 
	if(isset($_POST['submit']))
	{
		$name = $_POST['name'];
		$username = $_POST['username'];
		$password = $_POST['password'];
		

		$result = $crud->execute("INSERT into tecnical_team(name, username, password) values ('$name','$username', '$password')");

		if($result)
		{
			echo "alert('sucess')";
			header("Location:TecnicalTeamlist.php");
		}
		else{
			echo "Insertion Problem!";
		}
	}
?>