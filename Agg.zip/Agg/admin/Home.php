
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
</head>
<body bgcolor="Gold">
	
	<br><br><br><br><br>
	<h1 align="center">Welcome To Home Page</h1>
	<img src="Home.jpg" alt=" " width="1500" height="300">
	<br><br><br>
	
</body>
</html>

