<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once 'Crud.php';

$crud = new Crud();

$query = "Select * from crops order by id";

$result = $crud->getData($query);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Crops</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body bgcolor="DarkCyan">
	
	<br><br><br><br><br><br><br><br><br><br>
	<h1 align="center">Crops List with Price</h1>
	<br><br>
<form action="Crops.php" method="POST" enctype="multipart/form-data"/>
	<center>
		<input type="text" name="c_name" placeholder="Crops Name"/><br>
		<input type="text" name="c_details" placeholder="Crops details"/><br>
		<input type="text" name="c_price" placeholder="Crops Price"/><br>
		<input type="file" name="image" id="image" /> <br>
		<input type="submit" name="submit" value="Submit"><br>
	</center>
<form/>
<br>
<br>
<center>

	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col"> Crop Name </td>
				<th scope="col"> Crop Details </td>
				<th scope="col"> Crop Price</td>
			</tr>
	    </thead>
	    <tbody>
	<?php
		foreach($result as $key=>$res)
		{
			echo "<tr>";
			echo "<td>".$res['crop_name']."</td>";
			
			echo "<td>".$res['crop_details']."</td>";
			
			echo "<td>".$res['crop_price']."</td>";
			
			echo "<td><img src='data:image/jpeg;base64,".base64_encode($res['crop_photo'] )."' height='50' width='50' class='img-thumnail'/></td>";
			echo "</tr>";
		}
		?>
		</tbody>
	</table>
</center>
	
    <h1> Country Cereal Balance Sheet </h1>
	<img src="Balance Sheet.jpg"  height="200" width="280"/>
	<br>
	<h1> Crop Calender</h1>
	<img src="Crop Calender.jpg" height="200" width="280"/>	
    
	<div class="content">
		<span class="title">Crops List with Price</span>
    </div>
	</body>
</html>
<?php 
	if(isset($_POST['submit']))
	{
		$c_name = $_POST['c_name'];
		$c_details = $_POST['c_details'];
		$c_price = $_POST['c_price'];
		$c_img = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

		$result = $crud->execute("INSERT into crops(crop_name, crop_details, crop_price, crop_photo) values ('$c_name','$c_details','$c_price', '$c_img')");

		if($result)
		{
			header("Location:Crops.php");
		}
		else{
			echo "Insertion Problem!";
		}
	}
?>

<script>  
	$(document).ready(function(){  
		$('#submit').click(function(){  
			var image_name = $('#image').val();  
			if(image_name == '')  
			{  
					alert("Please Select Image");  
					return false;  
			}  
			else  
			{  
					var extension = $('#image').val().split('.').pop().toLowerCase();  
					if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
					{  
						alert('Invalid Image File');  
						$('#image').val('');  
						return false;  
					}  
			}  
		});  
	});  
</script>

