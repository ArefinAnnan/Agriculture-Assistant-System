<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>profile</title>
</head>
<body  align="center" bgcolor="DarkCyan">
	
	<fieldset>
				<legend><h1>Profile</h1></legend>
	<form action="Profile.php" method="POST">
		<label for="username">Username: </label>
		<input type="text" name="username" id="username" value=" ">

		<br><br>

		<label for="newusername">New User Name: </label>
		<input type="newusername" name="newusername" id="newusername" value="">

		<br><br>

		<label for="password">Password: </label>
		<input type="text" name="password" id="password" value=" ">

		<br><br>

		<label for="newpassword">New User Name: </label>
		<input type="newpassword" name="newpassword" id="newpassword" value="">

		<br><br>
		<input type="submit" name="submit" value="Update">

	</fieldset>	
	</form>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	
</body>
</html>


<?php 
include_once 'Crud.php';

$crud = new Crud();
	if(isset($_POST['submit']))
	{
		$username = $_POST['username'];
		$newusername = $_POST['newusername'];
		$password = $_POST['password'];
		$newpassword = $_POST['newpassword'];

		$result = $crud->execute("Update admin SET username ='$newusername', password='$newpassword' where id = '1'");

		if($result)
		{
			echo "<script>alert('Success')</script>";
		}
		else
		{
			echo "Problem!";
		}
	}
?>