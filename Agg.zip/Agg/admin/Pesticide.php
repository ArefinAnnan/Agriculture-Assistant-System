<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once 'Crud.php';

$crud = new Crud();

$query = "Select * from pesticides order by id";

$result = $crud->getData($query);

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Crops</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<link rel="stylesheet" href="style.css">
</head>
<body bgcolor="DarkCyan">
	
	<br><br><br><br><br><br><br><br><br><br>
	<h1 align="center">Pesticides List with Photos and Price..... </h1>
	<br><br>
<form action="Pesticide.php" method="POST" enctype="multipart/form-data"/>
	<center>
		<input type="text" name="p_name" placeholder="Pesticide Name"/><br>
		<input type="text" name="p_details" placeholder="Pesticide details"/><br>
		<input type="text" name="p_price" placeholder="Pesticide Price"/><br>
		<input type="file" name="image" id="image" /> <br>
		<input type="submit" name="submit" value="Submit"><br>
	</center>
<form/>
<br>
<br>
<center>

	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col"> Pesticide Name </td>
				<th scope="col"> Pesticide Details </td>
				<th scope="col"> Pesticide Price</td>
				<th scope="col"> Photo</td>
			</tr>
	    </thead>
	    <tbody>
	<?php
		foreach($result as $key=>$res)
		{
			echo "<tr>";
			echo "<td>".$res['pesticides_name']."</td>";
			echo "<td>".$res['pesticides_details']."</td>";
			echo "<td>".$res['pesticides_price']."</td>";
			echo "<td><img src='data:image/jpeg;base64,".base64_encode($res['pesticides_photo'] )."' height='50' width='50' class='img-thumnail'/></td>";
			echo "</tr>";
		}
		?>
		</tbody>
	</table>
</center>
	<div class="pp">
<h1> Environmental Effects of Pesticides </h1>
	<img src="Environmental Effects of Pesticides.jpg"  height="200" width="280"/>
    </div>
	<br>
	<div class="pp1"> 
	<h1> Impact of Pesticides</h1>
	<img src="Impact of Pesticides.jpg" height="200" width="280"/>
    </div>
	<p></p>
</body>
</html>
<?php 
	if(isset($_POST['submit']))
	{
		$p_name = $_POST['p_name'];
		$p_details = $_POST['p_details'];
		$p_price = $_POST['p_price'];
		$p_img = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));

		$result = $crud->execute("INSERT into pesticides(pesticides_name, pesticides_details, pesticides_price, pesticides_photo) values ('$p_name','$p_details','$p_price', '$p_img')");

		if($result)
		{
			header("Location:Pesticide.php");
		}
		else{
			echo "Insertion Problem!";
		}
	}
?>

<script>  
	$(document).ready(function(){  
		$('#submit').click(function(){  
			var image_name = $('#image').val();  
			if(image_name == '')  
			{  
					alert("Please Select Image");  
					return false;  
			}  
			else  
			{  
					var extension = $('#image').val().split('.').pop().toLowerCase();  
					if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
					{  
						alert('Invalid Image File');  
						$('#image').val('');  
						return false;  
					}  
			}  
		});  
	});  
</script>





