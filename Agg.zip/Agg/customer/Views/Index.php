<?php 
	require '../Controllers/includes/Header.php'; 
	require '../Controllers/includes/Navigation2.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>First Page</title>
</head>
<body bgcolor="Green">
	
	<br><br><br><br><br>
	<h1 align="center">Welcome T o Agriculture World</h1>
	<img src="Power.jpg" alt=" " width="1500" height="300">
	<br><br><br>
	
</body>
</html>

<?php 
	require '../Controllers/includes/Footer.php'; 
?>