<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>

<?php 
	require '../Controllers/includes/Header.php'; 
	require '../Controllers/includes/Navigation.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
</head>
<body bgcolor="Gold">
	
	<br><br><br><br><br>
	<h1></h1>
	<h1 align="center">Welcome To Home Page</h1>
	<img src="Home.jpg" alt=" " width="1500" height="300">
	<br><br><br>
	
</body>
</html>

<?php 
	require '../Controllers/includes/Footer.php'; 
?>