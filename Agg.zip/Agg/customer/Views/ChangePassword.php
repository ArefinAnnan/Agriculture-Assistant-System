<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php 
	require '../Controllers/includes/Header.php';
	require '../Controllers/includes/Navigation.php';
	require '../Controllers/PasswordChangeAction.php'; 
?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Change Password</title>
</head>
<body align="center" bgcolor="Plum">

	<br/>
	

		<form action="ChangePassword.php" method="POST">
			<fieldset>
				<legend><h1>Change Password</h1></legend>
			<label for="currentpass">Current Password<span style="color: red">*</span>: </label>
			<input type="text" name="currentpass" id="currentpass">
			
			<br><br>
			<label for="newpass">New Password<span style="color: red">*</span>: </label>
			<input type="text" name="newpass" id="newpass">
		
			<br><br>
			<label for="confirmnewpass">Confirm New Password<span style="color: red">*</span>: </label>
			<input type="text" name="confirmnewpass" id="confirmnewpass">
			
			<br><br>
			<input type="submit" name="submit" value="Confirm">
			</fieldset>
			
		</form>
		<br>
		<br><br><br><br><br><br><br><br><br><br><br>


		


</body>
</html>

<?php
			require '../Controllers/includes/Footer.php'; 
?>

<?php 
include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();
	if(isset($_POST['submit']))
	{
        $username = $_SESSION['username'];
		$currentpass = $_POST['currentpass'];
		$newpass = $_POST['newpass'];
        $confirmnewpass = $_POST['confirmnewpass'];
        // var_dump($username);
        // die();
        if($newpass != $confirmnewpass)
        {
            echo "<script>alert('Pleace Check Both Password')</script>";
        }
        else
        {
            $result = $crud->execute("Update user SET password ='$newpass' where username = '$username'");

            if($result)
            {
                echo "<script>alert('Success')</script>";
                //header("location:../Views/ChangePassword.php");
            }
            else
            {
                echo "Problem!";
            }
        }
	}
?>

