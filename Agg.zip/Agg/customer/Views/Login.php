<?php 
	require '../Controllers/includes/Header.php'; 
	require '../Controllers/LoginAction.php';
	require '../Controllers/includes/Navigation3.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
</head>
<body  align="center" bgcolor="DarkCyan">
	<fieldset>
				<legend><h1>Login for Customers</h1></legend>
	<form action="../Controllers/LoginAction.php" method="POST">
		<label for="username">Username: </label>
		<input type="text" name="username" id="username" value="">

		<br><br>

		<label for="password">Password: </label>
		<input type="password" name="password" id="password" value="">

		<br><br>

		<input type="checkbox" name="rememberme" id="rememberme" value="1">
		<label for="rememberme">Remember Me</label>

		<input type="submit" name="login" value="Login">

	</fieldset>	
	</form>

	<br>
	Not yet a Member? <a href="Registration.php">Sign Up</a>
	<br>

	<fieldset>
				<legend><h2>Login for Technical Support Team</h2></legend>
				<form action="../Controllers/LoginAction.php" method="POST">
		<label for="username">Username: </label>
		<input type="text" name="username" id="username" value="">

		<br><br>

		<label for="password">Password: </label>
		<input type="password" name="password" id="password" value="">

		<br><br>

		<input type="checkbox" name="rememberme" id="rememberme" value="1">
		<label for="rememberme">Remember Me</label>

		<input type="submit" name="login" value="Login">
	
				<a align="center" href="#.php" >Click Here</a>
	</fieldset>	
</form>
	
	<br>



	<fieldset>
				<legend><h2>Login for Admin </h2></legend>
				<form action="../Controllers/LoginAction.php" method="POST">
		<label for="username">Username: </label>
		<input type="text" name="username" id="username" value="">

		<br><br>

		<label for="password">Password: </label>
		<input type="password" name="password" id="password" value="">

		<br><br>

		<input type="checkbox" name="rememberme" id="rememberme" value="1">
		<label for="rememberme">Remember Me</label>

		<input type="submit" name="login" value="Login">
				<a align="center" href="Login1.php" >Click Here</a>
	
	</fieldset>	
</form>
	
</body>
</html>
<?php 
    	require '../Controllers/includes/Footer.php'; 
    ?>