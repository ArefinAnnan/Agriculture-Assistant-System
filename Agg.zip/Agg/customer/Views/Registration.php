<?php 
    require '../Controllers/includes/Header.php';
    require '../Controllers/RegistrationAction.php'; 
?>
<!DOCTYPE html>
<html>
<center>
<head>
<meta charset="utf-8">
<title>Registration</title>
</head>
<body bgcolor="Aqua">
    <fieldset>
                <legend><h1>Registration</h1></legend>

<form action="../Controllers/RegistrationAction.php" method="POST">
    <label for="firstname">পুরো নাম<span style="color: red">*</span>: </label>
    <input type="text" name="fullname" id="fullname">
    <span style="color: red"></span>
    <br><br>
    <label for="username">ইউজারনেম<span style="color: red">*</span>: </label>
    <input type="text" name="username" id="username">
    <!-- <span style="color: red"><?php echo $usernameErr; ?></span> -->
    <br><br>
    <label for="lastname">বয়স<span style="color: red">*</span>: </label>
    <input type="text" name="age" id="age">
    <!-- <span style="color: red"><?php echo $lastNameErr; ?></span> -->
    <br><br>
    <label for="password">পাসওয়ার্ড<span style="color: red">*</span>: </label>
    <input type="text" name="password" id="password">
    <!-- <span style="color: red"><?php echo $passwordErr; ?></span> -->
    <br><br>
    <input type="submit" name="submit" value="Register">

    </fieldset>
    <td>
        Already a Member? <a href="Login.php">Login</a>
    </td>
        
</form>



<br>



<!-- <span style="color: green"><?php echo $successfulMessage; ?></span>
<span style="color: red"><?php echo $errorMessage; ?></span> -->



<?php



function read() {
$file = fopen(filepath, "r");
$fz = filesize(filepath);
$fr = "";
if($fz > 0) {
$fr = fread($file, $fz);
}
fclose($file);
return $fr;
}
?>
<br><br><br><br><br><br><br><br><br><br><br><br><br>
    

</body>
</center>
</html>
<?php 
        require '../Controllers/includes/Footer.php'; 
    ?>