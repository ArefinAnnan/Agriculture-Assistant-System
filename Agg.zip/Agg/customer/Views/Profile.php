<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php 
	require '../Controllers/includes/Header.php';
	require '../Controllers/includes/Navigation.php'; 
?>

<!DOCTYPE html>
<html>
<head>
	<title>profile</title>
</head>
<body  align="center" bgcolor="DarkCyan">
	
	<fieldset>
				<legend><h1>Profile</h1></legend>
	<form action="Profile.php" method="POST">
		<label for="username">Username: </label>
		<input type="text" name="username" id="username" value="">

		<br><br>

		<label for="newusername">New User Name: </label>
		<input type="newusername" name="newusername" id="newusername" value="">

		<br><br>
		<input type="submit" name="submit" value="Update">

	</fieldset>	
	</form>
	<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	
</body>
</html>
<?php 
		require '../Controllers/includes/Footer.php'; 
?>

<?php 
include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();
	if(isset($_POST['submit']))
	{
		$username = $_SESSION['username'];
		$newusername = $_POST['newusername'];
		
		$result = $crud->execute("Update user SET username ='$newusername' where username = '$username'");
		
		if($result)
		{
			echo "<script>alert('Success')</script>";
			header("location:../Controllers/LogoutAction.php");
		}
		else
		{
			echo "Problem!";
		}
	}
?>
