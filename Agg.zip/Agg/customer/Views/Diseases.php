<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();

$query = "Select * from disease order by id";

$result = $crud->getData($query);

?>

<?php 
	require '../Controllers/includes/Header.php'; 
	require '../Controllers/includes/Navigation.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Disease</title>
</head>
<body bgcolor="orange">
	
	<br><br>
	<h1 align="center">Disease Details with Photos and Videos..... </h1>
	<br><br>

	<div class="row" style="text-align:center;">
		<?php foreach($result as $res) {?>
	<div class="col-sm-3">
		<div class="card">
		<div class="card-body">
			<?php echo '<img src="data:image/jpeg;base64,'.base64_encode($res['disease_photo']).'" style="height: 200px; width:290px"/>'; ?>
			<h5 class="card-title">Name: <?php echo $res['disease_name']?></h5>
			<p class="card-text">Details: <?php echo $res['disease_details']?></p>
		</div>
		</div>
	</div>
	<?php }?>
</div>
			
</body>
</html>

<?php 
	require '../Controllers/includes/Footer.php'; 
?>
