<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();
$client = $_SESSION['username'];
$query = "Select * from crops_order where username = '$client' order by id";
$query1 = "Select * from pesticides_order where username = '$client' order by id";
$support = "Select * from support where client = '$client' or receiver = '$client'";

$result = $crud->getData($query);
$result1 = $crud->getData($query1);
$s_query = $crud->getData($support);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support</title>
</head>
<body>
<center>
<h1>List of Crops You ordered</h1>
<table class="table">
	<thead class="thead-dark">
		<tr>
			<th scope="col"> Crop Name </td>
			<th scope="col"> Crop Price </td>
			<th scope="col"> Phone Number</td>
			<th scope="col"> Total Price</td>
		</tr>
	</thead>
	<tbody>
<?php
	foreach($result as $key=>$res)
	{
		echo "<tr>";
		echo "<td>".$res['crop_name']."</td>";
		echo "<td>".$res['crop_price']."</td>";
		echo "<td>".$res['phone_number']."</td>";
		echo "<td>".$res['total_price']."</td>";
		echo "</tr>";
	}
	?>
	</tbody>
</table>
</center>
<center>
<h1>List of Pesticide You ordered</h1>
	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col"> Pesticide Name </td>
				<th scope="col"> Pesticide Price </td>
				<th scope="col"> Phone Number</td>
				<th scope="col"> Total Price</td>
			</tr>
	    </thead>
	    <tbody>
	<?php
		foreach($result1 as $key=>$res1)
		{
			echo "<tr>";
			echo "<td>".$res1['pesticides_name']."</td>";
			echo "<td>".$res1['pesticides_price']."</td>";
			echo "<td>".$res1['phone_number']."</td>";
			echo "<td>".$res1['total_price']."</td>";
			echo "</tr>";
		}
		?>
		</tbody>
	</table>
</center>

<form action="Support.php" method="POST">
	<center>
		<h1>Send Messege to Support</h1>
		<input type="text" name="subject" placeholder="Subject"/><br>
		<input type="text" name="messege" placeholder="Messege"/><br>
		<input type="submit" name="submit" value="Submit"><br>
	</center>
<form/>

<center>
<h1>Messeges from Support</h1>
	<table class="table">
		<thead class="thead-dark">
			<tr>
				<th scope="col"> Sender </td>
				<th scope="col"> Receiver </td>
				<th scope="col"> Subject </td>
				<th scope="col"> Messege </td>
			</tr>
	    </thead>
	    <tbody>
	<?php
		foreach($s_query as $key=>$s_query)
		{
			echo "<tr>";
			echo "<td>".$s_query['sender']."</td>";
			echo "<td>".$s_query['receiver']."</td>";
			echo "<td>".$s_query['subject']."</td>";
			echo "<td>".$s_query['messege']."</td>";
			echo "</tr>";
		}
		?>
		</tbody>
	</table>
</center>

</body>
</html>

<?php 
	if(isset($_POST['submit']))
	{
		$sender = $_SESSION['username'];
		$receiver = "support";
		$subject = $_POST['subject'];
		$messege = $_POST['messege'];
		$client = $_SESSION['username'];

		$query = "select COUNT(sender) from support where sender = '$sender'";
		$check = $crud->getData($query);

		foreach($check as $chk)
		{
			$checkmsg = $chk["COUNT(sender)"];
		}
		
		if($checkmsg != 0)
		{
			echo "<script>alert('You Already send a support messege. Please Wait before you send another')</script>";
		}
		else
		{
			$result = $crud->execute("INSERT into support(sender, receiver, subject, messege, client) values ('$sender',
			'$receiver', '$subject', '$messege', '$client')");

			if($result)
			{
				header("Location:Support.php");
			}
			else{
				echo "Insertion Problem!";
			}
		}
	}
?>