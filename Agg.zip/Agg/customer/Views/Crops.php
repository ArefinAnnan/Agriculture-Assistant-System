<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();

$query = "Select * from crops order by id";

$result = $crud->getData($query);

?>

<?php 
	require '../Controllers/includes/Header.php'; 
	require '../Controllers/includes/Navigation.php';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Crops</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body bgcolor="DarkCyan">
	
	<br><br><br><br><br><br><br><br><br><br>
	<h1 align="center">Crops List with Price</h1>
	<br>

	<div class="row">
		<?php foreach($result as $res) {?>
	<div class="col-sm-3">
		<div class="card">
		<div class="card-body">
			<!-- <img class="card-img-top" src="<?php echo $res['crop_photo']?>" alt="Card image cap"> -->
			<?php echo '<img src="data:image/jpeg;base64,'.base64_encode($res['crop_photo']).'" style="height: 200px; width:290px"/>'; ?>
			<h5 class="card-title"><?php echo $res['crop_name']?></h5>
			<p class="card-text"><?php echo $res['crop_details']?></p>
			<p class="card-text"><?php echo $res['crop_price']?></p>
			<a href="buycrops.php?id=<?php echo $res['id'] ?>" class="btn btn-primary">Buy</a>
		</div>
		</div>
	</div>
	<?php }?>
</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
			
</body>
</html>

<?php 
	require '../Controllers/includes/Footer.php'; 
?>
