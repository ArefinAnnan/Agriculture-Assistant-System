<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();

$id = $_GET['id'];

$query = "Select * from pesticides where id = '$id'";

$result = $crud->getData($query);

foreach($result as $res)
{
    $pesticides_name = $res['pesticides_name'];
    $pesticides_details = $res['pesticides_details'];
    $pesticides_price = $res['pesticides_price'];
}

$username = $_SESSION['username'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy crops</title>
</head>
<body>
    <form action="buypesticides.php" method="POST">
    <label for="">Pesticides Name</label>
    <input type="text" name="pesticides_name" value="<?php echo $pesticides_name ?>" readonly /> <br>
    <label for="">Pesticides Details</label>
    <input type="text" name="pesticides_details" value="<?php echo $pesticides_details ?>" readonly /> <br>
    <label for="">Pesticides Price Per KG</label>
    <input type="text" name="pesticides_price" value="<?php echo $pesticides_price ?>" readonly /> <br>
    <label for="">Pesticides Name</label>
    <input type="text" name="username" value="<?php echo $username ?>" readonly /> <br>
    <label for="">Phone Number</label>
    <input type="text" name="phone_number" value=""  required/> <br>
    <label for="">Order Amount in KG</label>
    <input type="text" name="order_amount" value=""  required/> <br>
    <!-- <label for="">Total Price</label>
    <input type="text"  name="total_price" value=""  /> <br> -->
    <input type="submit" name="submit" value="Confirm Order">
    </form>
</body>
</html>

<?php 
if(isset($_POST['submit']))
{
    $username = $_SESSION['username'];
    $pesticides_name = $_POST['pesticides_name'];
    $pesticides_price = $_POST['pesticides_price'];
    $phone_number = $_POST['phone_number'];
    $order_amount = $_POST['order_amount'];
    $total_price = $pesticides_price*$order_amount;
    
    $result = $crud->execute("INSERT into pesticides_order(username,pesticides_name, pesticides_price, phone_number, order_amount, total_price) VALUES('$username','$pesticides_name','$pesticides_price','$phone_number', '$order_amount', '$total_price')");
    
    if($result)
    {
        echo "<script>alert('Success')</script>";
        header("location:Crops.php");
    }
    else
    {
        echo "Problem!";
    }
}
?>
