<?php
	session_start();
	if(!isset($_SESSION['username']))
	{
		header("location:Login.php");
	}
?>
<?php

include_once '../Controllers/Config/CRUD.php';

$crud = new Crud();

$id = $_GET['id'];

$query = "Select * from crops where id = '$id'";

$result = $crud->getData($query);

foreach($result as $res)
{
    $crop_name = $res['crop_name'];
    $crop_details = $res['crop_details'];
    $crop_price = $res['crop_price'];

}

$username = $_SESSION['username'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buy crops</title>
</head>
<body>
    <form action="buycrops.php" method="POST">
    <label for="">Crop Name</label>
    <input type="text" name="crop_name" value="<?php echo $crop_name ?>" readonly /> <br>
    <label for="">Crop Details</label>
    <input type="text" name="crop_details" value="<?php echo $crop_details ?>" readonly /> <br>
    <label for="">Crop Price Per KG</label>
    <input type="text" name="crop_price" value="<?php echo $crop_price ?>" readonly /> <br>
    <label for="">User Name</label>
    <input type="text" name="username" value="<?php echo $username ?>" readonly /> <br>
    <label for="">Phone Number</label>
    <input type="text" name="phone_number" value=""  required/> <br>
    <label for="">Order Amount in KG</label>
    <input type="text" name="order_amount" value=""  required/> <br>
    <label for="">Total Price</label>
    <!-- <input type="text"  name="total_price" value=""  /> <br> -->
    <input type="submit" name="submit" value="Confirm Order">
    </form>
</body>
</html>

<?php 
if(isset($_POST['submit']))
{
    $username = $_SESSION['username'];
    $crop_name = $_POST['crop_name'];
    $crop_price = $_POST['crop_price'];
    $phone_number = $_POST['phone_number'];
    $order_amount = $_POST['order_amount'];
    $total_price = $crop_price*$order_amount;
    
    $result = $crud->execute("INSERT into crops_order(username,crop_name, crop_price, phone_number, order_amount, total_price) VALUES('$username','$crop_name','$crop_price','$phone_number', '$order_amount', '$total_price')");
    
    if($result)
    {
        echo "<script>alert('Success')</script>";
        header("location:Crops.php");
    }
    else
    {
        echo "Problem!";
    }
}
?>
