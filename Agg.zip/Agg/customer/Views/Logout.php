<?php 
	require '../Controllers/includes/Header.php'; 
	require '../Controllers/includes/Navigation.php';
?>

	
<a href="Index.php">Log Out</a>
	


<?php 
	require '../Controllers/includes/Footer.php'; 
?>