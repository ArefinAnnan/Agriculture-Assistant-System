<center>
		<?php
		echo "<hr>";
		echo "<p><b>© Copyright " . date("Y") . " by Mid Term Project. All Rights Reserved.</b></p>";
		?>
	</center>