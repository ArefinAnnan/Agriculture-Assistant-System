	<fieldset>
	<h3 align="center">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;


			<a href="Home.php">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="Crops.php">Crops</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="Diseases.php">Diseases</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="Pesticide.php">Pesticide</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="Profile.php">Profile</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="ChangePassword.php">Change Password</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="../Views/Support.php">Support</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<a href="../Controllers/LogoutAction.php">Log Out</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			
	</h3>		
	</fieldset>

