<center>
		<?php
		echo "<p><h1>Agricultural Assistant System</h1></p>";
		echo "<hr>";
		?>
</center>
