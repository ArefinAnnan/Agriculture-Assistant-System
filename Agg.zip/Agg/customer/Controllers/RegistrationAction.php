<?php
	
	include_once 'Config/CRUD.php';
	
	$crud = new Crud();

	if(isset($_POST['submit']))
	{
		$fullname = $_POST['fullname'];
        $username = $_POST['username'];
		$age = $_POST['age'];
		$password = $_POST['password'];

				$result = $crud->execute("INSERT into user(full_name,username, age, password) VALUES('$fullname','$username','$age','$password')");
				
				if($result)
				{
					echo "<h3><script>alert('Saved');</script></h3>";
					header("location:../Views/Login.php");
				}
				else
				{
					echo "<h3><script>alert('Problem');</script></h3>";
				}
		
	}
		
?>